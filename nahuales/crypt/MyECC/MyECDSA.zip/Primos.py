#-------------------------------------------------------------------------------
# Name:        primos.py
# Purpose:     Generar listado de numeros primos
#
# Author:      ISC. Carlos Enrique Quijano Tapia
#
# Created:     03/11/2013
# Copyright:   (c) Kike 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import pickle
import os

class PRIME(object):

	primes = [2, 3, 5, 7, 11]
	lastCalc = 11

	def __init__(self):
		""" Busca números primos """
		# De existir busca el archivo de precálculos
		pathfile = os.path.join(os.path.dirname(os.path.abspath(__file__)),
				'primes.pickle')
		if os.path.exists(pathfile):
			with open('primes.pickle', mode='rb') as file:
				self.lastCalc = pickle.load(file)
				self.primes = pickle.load(file)
				file.close()


	def __del__(self):
		self.__svPrimes()
##		pass


	def isPrime(self, number):
		""" Verifiva sí un número es primo """
		# Checa sí ya se ha calculado este número primo
		if number > self.lastCalc:
##			print('Buscando primos')    # DEBUGG
			self.fndPrimes(number)

		if number in self.primes:
			return True
		else:
			return False


	def isPrimeSlow(self, number):
		flaPrime = True
		for i in range(2, number):
			if number % i == 0:
				flaPrime = False
				break

		return flaPrime


	def __calcPrime(self, number):
		""" Calcula sí el número es primo, verificando el residúo con los
		números primos anteriores conocidos"""

		flaPrime = True
		limit = number // 2
		for i in self.primes:
			if number % i == 0:
				flaPrime = False
				break
			if i > limit:
				break

		# Sí es primo, agregalo a la lista
		if flaPrime:
##			print(number, 'es primo')   # DEBUGG
			self.primes.append(number)

		self.lastCalc = number


	def fndPrimes(self, until):
		""" Calcula los primos faltantes hasta el número pedido """
		for num in range(self.lastCalc + 1, until + 1):
			self.__calcPrime(num)


	def __svPrimes(self):
		""" Salva los números primos encontrados """
		with open('primes.pickle', mode='wb') as file:
			pickle.dump(self.lastCalc, file)
			pickle.dump(self.primes, file)
			file.close()

def main():
	from datetime import datetime
	print('\nIniciando: ', datetime.now())
	born = datetime.now()

	prime = PRIME()

	numero = int(30677)
##	numero = int(1 * 10 ** 5)
	if prime.isPrime(numero):
		print('El numero', numero, 'es primo')
	else:
		print(numero, 'NO es primo')

	numeros = [1, 3, 6, 5113, 10226, 15339, 30678]
	for i in numeros:
		if prime.isPrime(i):
			print('El numero', i, 'es primo')
		else:
			print(i, 'NO es primo')

##	print('La lenta')
##	for i in numeros:
##		if prime.isPrimeSlow(i):
##			print('El numero', i, 'es primo')
##		else:
##			print(i, 'NO es primo')

	print(len(prime.primes), 'números primos almacenados en memoria')

	print('\nTiempo consumido: ', datetime.now() - born)

if __name__ == '__main__':
    main()
